
public class RandomWord {
    public static void main(String[] args) {
System.out.println("Running through the woods, running through the woods");
    }
}
